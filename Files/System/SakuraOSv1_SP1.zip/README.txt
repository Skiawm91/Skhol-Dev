感謝您選用SakuraOS!

如果有問題或遇到bug 請聯繫這個dc帳號:
Kiawm91#0001

使用手冊:

[help] 取得幫助
[notepad] 開啟記事本 
[paint] 開啟小畫家
[calc] 開啟計算機
[clear] 清除螢幕
[apps] 程式列表