SakuraOS 22H2 更新！
此版本延續了一貫風格，仍以Batch
這個版本更新了新東西！例如Bug指令無法使用
SakuraOS Explorer 也更新了
New Web https://sakurainc.com
內容 /後面有
/news
/store
以上